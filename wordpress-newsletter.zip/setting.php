<?php
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "wp";
	//fill this with your table prefix
	$dbprefix = "wp_";
?>